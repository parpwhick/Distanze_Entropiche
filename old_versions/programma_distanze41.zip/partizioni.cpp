#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <stdio.h>
#include "strutture.h"

extern options opts;
extern double *mylog;

template<typename _Tp>
    inline const _Tp&
    min(const _Tp& __a, const _Tp& __b)
    {
      // concept requirements
      
      //return  __a < __b ? __b : __a;
      if (__a > __b)
	return __b;
      return __a;
    }

void general_partition::print() {
    if (opts.verbose > 1) {
        fprintf(stdout, "Lbl: {%d", labels[0]);
        for (int i = 1; i < N; i++)
            fprintf(stdout, ",%d", labels[i]); //- labels[0] + 1);
        fprintf(stdout, "}\n");
        
//        fprintf(stdout, "Adv: {%d", atom_positions[0]);
//        for (int k = 1; k < n; k++)
//            fprintf(stdout, ",%d", atom_positions[k]);
//        fprintf(stdout, "}\n");
    
    fprintf(stdout, "Nnb: {%d", nnb[0]);
    for (int i = 1; i < N; i++)
        fprintf(stdout, ",%d", nnb[i]);
    fprintf(stdout, "}\n");
    }
//    fprintf(stdout, "Sizes: {%d", atom_sizes[0]);
//    for (int i = 1; i < n; i++)
//        fprintf(stdout, ",%d", atom_sizes[i]);
//    fprintf(stdout, "}\n");
    //adding the entropy information
        fprintf(stdout, "Partitions[f]: %d, Shannon %f, Topological %f\n", n, entropia_shannon,
                entropia_topologica);
    
    
}

void partition::print() {
    // {1,3,4,...}
//    if (opts.verbose > 2) {
//        fprintf(stdout, "Simp: {%d", atom_positions[0]);
//        for (int k = 1; k < n; k++)
//            fprintf(stdout, ",%d", atom_positions[k]);
//        fprintf(stdout, "}\n");
//    }
    if (opts.verbose > 3) {
        // {1,0,0,1,0,1,...}
        fprintf(stdout, "Bin: {%d", binary[0]);
        for (int k = 1; k < N; k++)
            fprintf(stdout, ",%d", binary[k]);
        fprintf(stdout, "}\n");
    }
    fprintf(stdout, "Partitions[n]: %d, Shannon %f, Topological %f\n", n,entropia_shannon,
            entropia_topologica);
}

void entry::print() {
    //sequence name and code
    
    fprintf(stdout, "Seq%03d",this->index);
    if(opts.verbose>1)
        fprintf(stdout, " (%s)",this->name);
    if(this->n < 70 || opts.verbose > 3)
        fprintf(stdout, ": %s\n", this->seq);
    else
        fprintf(stdout, ": %.20s...\n", this->seq);
    
    //print the whole partition
    if(opts.verbose>2)
        Z->print();
    
    
    
    if (X && X->n) {
        //print the whole partition
        if (opts.verbose > 2)
            X->print();
        
    }
    fprintf(stdout,"\n");
    
}

template <typename T>
partition::partition(const T* seq, int len) {
    int i, j;
    
    //Total length of the partition is equal to the sequence
    N = len;
        
    binary = new int[len];
    //atom_positions = new int[len];

    //first one always start an atom
    binary[0] = 1;

    //checking for a different symbol from the one before
    //when that happens => new atom!
    for (i = 1; i < len; i++)
        binary[i] = seq[i] != seq[i - 1];

    //now going back and writing the atom positions
    j=0;
    for (i = 0; i < len; i++)
        if (binary[i]) {
            //atom_positions[j++] = i + 1;
            j++;
        }
    //number of atoms found - index++ of last the atom in the array (zero addressing)
    n = j;
    entropia_topologica=mylog[n];
    entropia_shannon=entropy_binary_partition(binary,N);

}

template <typename T>
general_partition::general_partition(const T* seq, int len,int fuzzy) {
    int i, j;
    //this run's  atoms count
    int label_count;
    //position of the last site belonging to the atom we're trying to add to
    int last_good;
    //Total length of the partition is equal to the sequence
    N = len;
    entropia_shannon=0;
    entropia_topologica=0;
    
    if(fuzzy==-1)
        fuzzy=opts.fuzzy;
     
    //position of first symbol (0 based index)
    //atom_positions = new int[N];
    
    //size of atoms (0 based index)
    //atom_sizes=new int[N];
    labels=new int[N];
    //setting the nearest-neighbor matrix up
    nnb=new int[N];
    
    const int EMPTY=-N-1;

    //presetting labels for this partition to 0
    for (i=0;i<N;i++){
        labels[i]=0;
        nnb[i]=EMPTY;
    }
    
    //beginning count of identified atoms
    label_count=0;
    //we check every site for belonging to a partition set
    for (i=0;i<N;i++){
        //if the site was already "colored" check the next one
        if (labels[i])
            continue;
        //we give a new label to the site
        label_count++;
        //atom_positions[label_count-1]=i;
        labels[i]=label_count;
        
        //we know that it belongs (first, trivial)
        last_good=i;
        int this_atom_size=1;
        nnb[i]=i;
        //now we add all the other possible sites to it, starting from i+1!
        //staying below N
        //and allowing a spacing of at most opts.fuzzy spaces between them
        for(j=i+1; j<last_good+fuzzy+2 && j<N; j++){
            
            //if it belongs to the same cluster...
            if(seq[j]==seq[i]){
                //..we label it accordingly
                labels[j]=label_count;
                //the last site's neighbor is the current one
                nnb[j]=i;
                //and marking it as "good" (since we're on an ordered line)
                last_good=j;
                this_atom_size++;
                
            }
        }
        //atom_sizes[label_count-1]=this_atom_size;
        entropia_shannon+=this_atom_size * mylog[this_atom_size];
        
        
    }
    //this many different atoms were found
    entropia_shannon=-entropia_shannon/N+mylog[N];
    n=label_count;
    entropia_topologica=mylog[n];

}
template general_partition::general_partition(const int *, int, int);

void entry::make_partition(){
        Z=new partition(seq,n);
        X=new general_partition(seq,n);
    }

general_partition::general_partition(int len) : partition(len) {
    n=0;
    N=len;
    entropia_topologica=0;
    entropia_shannon=0;
    
    if(N){
        //atom_sizes=new int[N];
        labels=new int[N];
        nnb=new int[N];
    }
}

int findroot(int i,int *ptr)
{
  if (ptr[i]<0) return i;
  return ptr[i] = findroot(ptr[i],ptr);
}

void general_partition::linear_intersection(general_partition *p1, general_partition *p2){
    int s1, s2;
    int i;
    
    //Total length of the partition is equal to the sequence
    //const int EMPTY=-N-1;   
    //setting the nearest-neighbor matrix up
    int *neighbors[2];
    
    
    //presetting labels for this partition to 0
    for (i = 0; i < N; i++) {
        //labels[i] = EMPTY;
        //E' piu corretto il valore EMPTY, ma per bellezza in 1D, ci metto 0
        labels[i]=-1;
    }
    entropia_topologica=0;
    entropia_shannon=0;
    
    //for (i=0; i<2;i++){
        neighbors[0]=p1->nnb;
        neighbors[1]=p2->nnb;
    //}
	#ifdef DEBUG
        printf("Neighbors:\n");
        for(i=0;i<N;i++){
            printf("%d ",neighbors[0][i]);
        }
        printf("\n");
        for(i=0;i<N;i++){
            printf("%d ",neighbors[1][i]);
        }
        printf("\n\n");
	#endif
    //we check every site for belonging to a partition set
    for (s1=1;s1<N;s1++){
        int r2,r1=s1;
	//for all neighbors, in this case - 2
        
	#ifdef DEBUG
	printf("Lbl: {%d",labels[0]);
        for(i=1;i<N;i++)
        printf(",%d",labels[i]);
        printf("}\n");
        
        printf("Rts: {%d",findroot(0,labels)+1);
        for(i=1;i<N;i++)
        printf(",%d",findroot(i,labels)+1);
        printf("}\n");
        #endif
        
	labels[s1]=-1;
        for(int j=0; j<2; j++){
		s2=neighbors[j][s1];
                if(s1==s2)
                    continue;
		r2=findroot(s2,labels);
//              printf("%d--->%d(%d)\n",s1,s2,r2);
		if(r1!=r2){
			if(labels[r1]>=labels[r2]){
//                           printf("%d=>%d\n",r1,r2);
				labels[r2]+=labels[r1];
				labels[r1]=r2;
				r1=r2;
			}
			else{
//                          printf("%d=>%d\n",r2,r1);
				labels[r1]+=labels[r2];
				labels[r2]=r1;
			}
		}

	}
    }
    int label_count=0;
    for(i=0;i<N;i++){
        if(labels[i]<0){
            //labels sono negativi!
            entropia_shannon+=labels[i]*mylog[-labels[i]];
            //atom_sizes[label_count]=-labels[i];
            //atom_positions[label_count]=i+1;
            label_count++;
        }
        nnb[i]=findroot(i,labels);
    }
    n=label_count;
    entropia_topologica=mylog[n];
    entropia_shannon=entropia_shannon/N+mylog[N];

}
