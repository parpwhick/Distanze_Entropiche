function [h,c,Z,numerosita] = cluster_count(distanza,n)

if(nargin < 2)
    n=13;
end

M=100;
[N,m]=size(distanza);
assert(N==m, 'La matrice non e` quadrata');
h=zeros(1,M);

Z=linkage(squareform(distanza),'complete');

if(nargin<2)
for j=1:M
    c=cluster(Z,'maxclust',j);
    for i=1:max(c)
        mu=sum(c==i);
        h(j)=h(j)+mu*log(mu);
    end
    h(j)=-h(j)/N+log(N);
end

plot(h);
title('Entropia di Shannon');
n=input('Numero di cluster? ');
end

c=cluster(Z,'maxclust',n);

sequenze_date=importdata('sequenze_date.txt','/');
label_anni=sequenze_date(:,1)+(sequenze_date(:,2)-1)/12+(sequenze_date(:,3)-1)/365;

first_appearance=zeros(1,n);
for i=1:n
    first_appearance(i)=min(label_anni(c==i));
end
[~,order1]=sort(first_appearance);

order2=order1;
for i=1:n
    order2(order1(i))=i;
end

ordinati=order2(c);
for i=1:n
    numerosita(i)=sum(ordinati==i);
end
scatter(label_anni,order2(c),50,order2(c),'filled');
%colormap('Lines');