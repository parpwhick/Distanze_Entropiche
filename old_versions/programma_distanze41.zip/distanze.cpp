#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <stdio.h>
#include "strutture.h"


int *common_factor;
int *reduced1;
int *reduced2;
int *product;
int *product_reduced;


extern options opts;
extern double *mylog;

void distance::allocate(int n) {
    common_factor = new int[n];
    reduced1 = new int[n];
    reduced2 = new int[n];
    product = new int[n];
    product_reduced = new int[n];
    labels = new int[n];
    pmatrix= new short[n*n];
}

distance::distance(int n) {
    N = n;
    allocate(N);
}

distance::distance(const distance &d1) {
    N = d1.N;
    allocate(N);
}

distance::~distance() {
    if (N) {
        delete[] common_factor;
        delete[] reduced1;
        delete[] reduced2;
        delete[] product;
        delete[] product_reduced;
        delete[] labels;
        delete[] pmatrix;
    }
    N = 0;
}

void distance::fill(entry& e1, entry& e2) {
    
    general_partition partizione_comune(e1.n);
    
    this->binary_partition(e1, e2);
    
    switch(opts.alg){
        case PMATRIX:
                this->generic_partition_pmatrix(e1.X,e2.X);
                break;
        case SORTED:            
	default:
                this->generic_partition_sorted(e1.X, e2.X);
                break;
    }
    
    this->hamming_distance(e1.seq, e2.seq);
  
    partizione_comune.linear_intersection(e1.X,e2.X);
    this->somiglianza=partizione_comune.entropia_shannon;
    this->somiglianza_t=partizione_comune.entropia_topologica;
}

void print_binary_partition(int*p, int N) {
    // |...|...||...|...
    for (int i = 0; i < N; i++)
        printf("%c", (p[i]) ? '|' : '.');
    printf("\n");
}

double entropy_binary_partition(int *p, int n) {
    //p: binary partition
    //n: total length
    int i = 0;
    int mu;
    int begin;
    double H = 0;

    //the first position always starts an atom
    begin = 0;
    for (i = 1; i < n; i++) {
        //whenever we find 1 (a new atom)
        if (p[i]) {
            //the closed (old)atom's length is calculated
            mu = i - begin;
            //the new one is ready to go
            begin = i;
            //we add the entropy, with the trick mu>0 and when mu=1 the log is 0
            if (mu > 1)
                H += (double) mu * mylog[mu];
        }
    }
    //we check the last one, in case it's left hanging
    mu = n - begin;
    if (mu > 1) H += mu * mylog[mu];

    //proper entropy normalization
    H = -H / n + mylog[n];
    return (H);
}

template <typename T>
void distance::hamming_distance(T* seq1, T* seq2) {
    this->dist_ham = 0;
    for (int i = 0; i < N; i++)
        this->dist_ham += (double) (seq1[i] != seq2[i]);
}


//function giving the distance between 2 partitions, by intersecting 
//and calculating the relevant entropy

void distance::binary_partition(entry &e1, entry &e2) {

    partition *first = e1.Z;
    partition *second = e2.Z;

    int N = e1.n;
    int coperture1 = 0, coperture2 = 0, coperture12 = 0, 
            coperture1r = 0, coperture2r = 0, coperture12r = 0,
            coperture_common=0;

    //the common factor of the partition, AND'ing
    for (int i = 0; i < N; i++)
        common_factor[i] = first->binary[i] & second->binary[i];
    common_factor[0] = 1;

    //reducing both the partitions XOR'ing with the common factor
    for (int i = 0; i < N; i++)
        reduced1[i] = common_factor[i] ^ first->binary[i];
    reduced1[0] = 1;
    for (int i = 0; i < N; i++)
        reduced2[i] = common_factor[i] ^ second->binary[i];
    reduced2[0] = 1;

    //the partition product/intersection, OR'ing
    for (int i = 0; i < N; i++)
        product[i] = first->binary[i] | second->binary[i];
    product[0] = 1;

    //intersection of the reduced partitions, OR'ing
    for (int i = 0; i < N; i++)
        product_reduced[i] = reduced1[i] | reduced2[i];
    //  alternatively, one could XOR the unreduced partitions
    //  intersection_reduced[i] =first->binary[i] ^ second->binary[i];
    product_reduced[0] = 1;

    for (int i = 0; i < N; i++) {
        coperture1 += first->binary[i];
        coperture2 += second->binary[i];
        coperture12 += product[i];
        coperture1r += reduced1[i];
        coperture2r += reduced2[i];
        coperture12r += product_reduced[i];
        coperture_common+=common_factor[i];
    }


    //calculating ALL the entropies (3 per non-reduced Rohlin dist, 3 per reduced)
    double
    h1 = entropy_binary_partition(first->binary, N),
            h2 = entropy_binary_partition(second->binary, N),
            hr1 = entropy_binary_partition(reduced1, N),
            hr2 = entropy_binary_partition(reduced2, N),
            h12 = entropy_binary_partition(product, N),
            hr12 = entropy_binary_partition(product_reduced, N);

    //packing the output tuple with the distances
    this->dist_s = 2 * h12 - h1 - h2;
    this->dist_s_r = 2 * hr12 - hr1 - hr2;
    this->dist_top = 2 * mylog[coperture12] - mylog[coperture1] - mylog[coperture2];
    this->dist_top_r = 2 * mylog[coperture12r] - mylog[coperture1r] - mylog[coperture2r];
    
    


}

/* VERSIONE GENERICA E CONCISA
 */
//dist_tuple general_distance(general_partition *p1, general_partition *p2){
//    dist_tuple res;
//    int i;
//    
//    for(i=0;i<p1->N;i++)
//        //How to make a unique label out of 2:
//        // l1 =       [00001234]
//        // l2 =       [00002945]
//        // l1 << 4 =  [12340000]
//        // l1 | l2 =  [12342945]
//        product[i]=(p1->labels[i]<<16)
//                | (p2->labels[i]);
//    
//    general_partition *p12=new general_partition(product,p1->N,p1->N);
//        
//    double  h12=p12->entropia_shannon,
//            h1=p1->entropia_shannon,
//            h2=p2->entropia_shannon,
//            t12=p12->entropia_topologica,
//            t1=p1->entropia_topologica,
//            t2=p2->entropia_topologica;
//    res.dist_fuzzy=2*h12-h1-h2;
//    res.dist_fuzzy_t = 2 * t12 - t1 - t2;
//
//    delete p12;
//    return(res);
//}
//

/* VERSIONE OTTIMIZZATA IN MEMORIA, 2x veloce
 */
void distance::generic_partition(general_partition *p1, general_partition *p2) {
    int i, j;
    int label_count = 0;
    int this_atom_size;
    double H = 0;



    //presetting labels for this partition to 0
    for (i = 0; i < N; i++) {
        reduced1[i] = 0;
    }
    for (i = 0; i < N; i++)
        product[i] = (p1->labels[i] << 16) | (p2->labels[i]);
    
    for (i = 0; i < N; i++) {
        if (reduced1[i])
            continue;

        label_count++;
        reduced1[i] = 1;
        this_atom_size = 1;
        int old_val=product[i];
        for (j = i + 1; j < N; j++) {
            if (product[j] == old_val) {
                reduced1[j] = 1;
                this_atom_size++;
            }
        }
        H += this_atom_size * mylog[this_atom_size];
    }
    H = -H / N + mylog[N];

    double h1 = p1->entropia_shannon,
            h2 = p2->entropia_shannon,
            t1 = p1->entropia_topologica,
            t2 = p2->entropia_topologica;
    this->dist_fuzzy = 2 * H - h1 - h2;
    this->dist_fuzzy_t = 2 * mylog[label_count] - t1 - t2;


}


int compare (const void * a, const void * b)
{
  return ( *(int*)a - *(int*)b );
}


void distance::generic_partition_sorted(general_partition *p1, general_partition *p2) {
    int i;
    int label_count = 0;
    double H = 0;
    int mu;
    int begin;


    for (i = 0; i < N; i++)
        product[i] = (p1->labels[i] << 16)
        | (p2->labels[i]);
    
    qsort(product,N,sizeof(int),compare);

    //the first position always starts an atom
    begin = 0;
    label_count=1;
    int old_val=product[0];
    for (i = 1; i < N; i++) {
        //whenever we find 1 (a new atom)
        if (product[i]!=old_val) {
            //a new atom starts
            label_count++;
            //the closed (old)atom's length is calculated
            mu = i - begin;
            //the new one is ready to go
            begin = i;
            //cache the new label to check
            old_val=product[i];
            //we add the entropy, with the trick mu>0 and when mu=1 the log is 0
            if (mu > 1)
                H += (double) mu * mylog[mu];
        }
    }
    //we check the last one, in case it's left hanging
    mu = N - begin;
    H += mu * mylog[mu];
    
    //normalize the result
    H = -H / N + mylog[N];

    double h1 = p1->entropia_shannon,
            h2 = p2->entropia_shannon,
            t1 = p1->entropia_topologica,
            t2 = p2->entropia_topologica;
    this->dist_fuzzy = 2 * H - h1 - h2;
    this->dist_fuzzy_t = 2 * mylog[label_count] - t1 - t2;


}

void distance::generic_partition_pmatrix(general_partition *p1, general_partition *p2) {
    int i;
    int pmax;
    int label_count=0;
    double H = 0;
    

    //limitiamo la matrice al numero minimo di righe*colonne
    pmax=(p1->n+1) * (p2->n+1);
        
    for (i=0;i<pmax;i++)
        pmatrix[i]=0;
    
    for (i = 0; i < N; i++)
        pmatrix[(p1->labels[i])*p2->n + p2->labels[i]]++;
    
    for(i=0;i<pmax;i++)
        if(pmatrix[i]){
            label_count++;
            H+=pmatrix[i]*mylog[pmatrix[i]];
        }
            
    //normalize the result
    H = -H / N + mylog[N];

    double h1 = p1->entropia_shannon,
            h2 = p2->entropia_shannon,
            t1 = p1->entropia_topologica,
            t2 = p2->entropia_topologica;
    this->dist_fuzzy = 2 * H - h1 - h2;
    this->dist_fuzzy_t = 2 * mylog[label_count] - t1 - t2;
}


