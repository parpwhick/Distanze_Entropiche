/* 
 * File:   strutture.h
 * Author: fake
 *
 * Created on January 13, 2012, 10:51 PM
 */

using namespace std;

enum algorithm {
    NORMAL,
    SORTED,
    PMATRIX,
    AUTO
};

enum source{
    RANDOM,
    FILES
};

typedef struct {
    int seq_len;
    int n_seq;
    source from;
    char filename[255];
    bool write;
    bool distance;

    int fuzzy;
    int seed;
    int verbose;
    int n_symbols;
    bool translate;
    
    int threads;
    algorithm alg;

}options;

struct dist_tuple {
    double dist_s;
    double dist_s_r;
    double dist_top;
    double dist_top_r;
    double dist_ham;
    double dist_fuzzy;
    double dist_fuzzy_t;
};

class partition {

public:
    //array of atom starting positions {1,4,5,...}
    int *atom_positions;
    //binary atom beginning codes {1,0,0,0,1,1,...}
    int *binary;
    //number of atoms found
    int n;
    //total length of the partition
    int N;
    
    double entropia_shannon;
    double entropia_topologica;
    void print();
    
    template <typename T>  partition(const T*seq, int len);
    partition(){
        n=0;
        N=0;
        binary=0;
        atom_positions=0;
    }
    ~partition(){
        if(n){
        delete[] atom_positions;
        delete[] binary;
        }
        n=N=0;
    }
};

class general_partition: public partition{

public :
    //labels identify generic atoms across the partition
    int *labels;
    //not to count them every time, we do it at initialization time
    int *atom_sizes;
    
    template <typename T> general_partition(const T* seq, int len,int fuzzy=-1);
    void print();
    
    ~general_partition(){
        if(n){
            delete []labels;
            delete []atom_sizes;
        }
    }
};



class entry {
public:
    //identifier of the sequence
    char* name;
    //string of symbols making the sequence
    char* seq;
    //length of the sequence
    int n;
    //sequence index, relevant only for printing
    int index;
    //partitioned sequence
    partition *Z;
    general_partition *X;

    void make_partition();
    
    void print();
    ~entry(){
        delete[] name;
        delete[] seq;
        delete Z;
        delete X;
        n=index=0;
    }
};


class distance{
private:
    void allocate(int n);
public:
    int *common_factor;
    int *reduced1;
    int *reduced2;
    int *product;
    int *product_reduced;
    int *labels;
    short *pmatrix;

    double dist_s;
    double dist_s_r;
    double dist_top;
    double dist_top_r;
    double dist_ham;
    double dist_fuzzy;
    double dist_fuzzy_t;
    double somiglianza;
    double somiglianza_t;
    
    int N;

    
    void binary_partition(entry &e1, entry &e2);
    void generic_partition(general_partition *p1, general_partition *p2);
    void generic_partition_sorted(general_partition *p1, general_partition *p2);
    void generic_partition_pmatrix(general_partition *p1, general_partition *p2);
    template <typename T> void hamming_distance(T* seq1, T* seq2);
    void fill(entry &e1, entry &e2);
    
    ~distance();
    distance(int n=1000);
    distance(const distance &d1);
    

};


void set_program_options(options &opt, int argc, char**argv) ;
void fill_entries_randomly(const options opt, entry *entries);
void fill_entries_from_file(options &opts, entry *entries);
double entropy_binary_partition(int *p, int n);