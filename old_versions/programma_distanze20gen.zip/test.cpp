#include <omp.h>
#include <cstdio>

using namespace std;


int n=5;
extern int n;

class simple{
	int n;
public:
	simple(int i=1){
		n=i;
		printf("Initialized to %d\n",n);
	}
	void print() {
		printf("Printing value %d\n",n);
	}
};


main(){
	simple a;
	printf("a=%d\n",n);
#pragma omp parallel for schedule(dynamic) private(a)
	 for(int n=0; n<10; ++n) a.print();
}
