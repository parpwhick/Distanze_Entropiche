clear dist*;
fclose('all');
clear fid*;
fid1=fopen('output-dist.bin','r');
fid2=fopen('output-distr.bin','r');
fid3=fopen('output-top.bin','r');
fid4=fopen('output-topr.bin','r');
fid5=fopen('output-ham.bin','r');
fid6=fopen('output-fuzzy.bin','r');
fid7=fopen('output-fuzzyt.bin','r');




n=822;



%distanze shannon, normali
dist_n=fread(fid1,[n,n],'double');
%distanze shannon, ridotte
dist_r=fread(fid2,[n,n],'double');
%distanze topologiche, normali
dist_t=fread(fid3,[n,n],'double');
%distanze topologiche, ridotte
dist_t_r=fread(fid4,[n,n],'double');
%distanze hamming
dist_ham=fread(fid5,[n,n],'double');
%distanze fuzzy
dist_f=fread(fid6,[n,n],'double');
%distanze fuzzy topologiche
dist_f_t=fread(fid7,[n,n],'double');

bins=100;
[hist_n,labels1]=hist(dist_n(dist_n>0),100);
[hist_r,labels2]=hist(dist_r(dist_r>0),100);
[hist_t,labels3]=hist(dist_t(dist_t>0),100);
[hist_t_r,labels4]=hist(dist_t_r(dist_t_r>0),100);
[hist_h,labels5]=hist(dist_ham(dist_ham>0),100);
[hist_f,labels6]=hist(dist_f(dist_f>0),100);
[hist_f_t,labels7]=hist(dist_f_t(dist_f_t>0),100);



subplot(2,2,1), plot(labels1,hist_n,'-*r',labels3,hist_t,'-*b');
legend('Shannon distance','Topological distance');
xlabel('Distance');
ylabel('Frequency');
subplot(2,2,2), plot(labels2,hist_r,'-*r',labels4,hist_t_r,'-*b');
legend('Shannon reduced dist','Topological reduced dist');
xlabel('Distance');
ylabel('Frequency');

subplot(2,2,3);
plot(labels6,hist_f,'-*r',labels4,hist_f_t,'-*b');
legend('Fuzzy S. dist.','Fuzzy top. dist.');
xlabel('Distance');
ylabel('Frequency');

subplot(2,2,4);
plot(labels5,hist_h,'-*b');
legend('Hamming dist');
xlabel('Distance');
ylabel('Frequency');