/* 
 * Author: Dawid Crivelli
 *
 * Started on January 11, 2012, 2:30 PM
 * 
 * 
 * Version: 3.0, 2012/01/15
 * -Generic partition building
 * -Partitioning of arbitrary symbol strings
 * -Generic intersection and (unreduced) distance
 * -Inheritance classes
 * 
 * Version: 2.0, 2012/01/13
 * -Reading from files
 * -Help system 
 * -Thorough input options
 * 
 * Version: 1.0, 2012/01/12
 * -Partitioning
 * -Distance matrix calculation
 */

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>

#include "strutture.h"

extern options opts;
double *mylog;


template<typename _Tp>
    inline const _Tp&
    max(const _Tp& __a, const _Tp& __b)
    {
      // concept requirements
      
      //return  __a < __b ? __b : __a;
      if (__a < __b)
	return __b;
      return __a;
    }

int main(int argc, char** argv) {
    int i;
    int fragments=0;
    
    double *dist_shan;
    double *dist_shan_r;
    double *dist_top;
    double *dist_top_r;
    double *dist_ham;
    double *dist_fuzzy;
    double *dist_fuzzy_t;
    double *dist_somiglianza;
    double *dist_somiglianza_t;
    FILE *out;
        
    set_program_options(opts,argc,argv);
        
    //random number initialization
    srand(opts.seed);
    
    //
    //  ALLOCATION OF MEMORY AND INITIALIZATION
    //
    entry *entries = new entry[opts.n_seq];
        
    //logarithm lookup table, 6x program speedup
    mylog = new double[opts.seq_len + 10];
    for (int i = 1; i < opts.seq_len + 10; i++)
        mylog[i] = log(i);
    mylog[0]=0;
    
    //
    //  CREATION OF RANDOM SEQUENCES (as entries)
    //
    if(opts.from==RANDOM){
        fill_entries_randomly(opts,entries);
    }

    //
    //  READ SEQUENCES FROM FILE
    //
    if(opts.from==FILES)
        fill_entries_from_file(opts,entries);
    
    if(opts.verbose)
        fprintf(stderr,"Entries filled\n");
    //
    //  ANALISYS OF LOADED SEQUENCES
    //
    for (i = 0; i < opts.n_seq; i++) {
        entries[i].make_partition();
        if (opts.verbose >0)
            entries[i].print();
        
    }
    
    for (i = 0; i < opts.n_seq; i++)
        fragments = max(fragments, entries[i].X->n);
    if (opts.alg == AUTO) {
        if (fragments > 180) {
            opts.alg = SORTED;
            fprintf(stderr,"Automatically selected sorted algorithm (fragments=%d)\n", fragments);
        } else {
            opts.alg = PMATRIX;
            fprintf(stderr,"Automatically selected pmatrix algorithm (fragments=%d)\n", fragments);
        }
    }
    
    
    //
    //  DISTANCE MEASUREMENTS
    //
    if(opts.distance==false)
        exit(0);
    
    
    //distance matrix allocation and zeroing,if needed
    dist_shan = new double[opts.n_seq * opts.n_seq];
    dist_shan_r = new double[opts.n_seq * opts.n_seq];
    dist_top = new double[opts.n_seq * opts.n_seq];
    dist_top_r = new double[opts.n_seq * opts.n_seq];
    dist_ham = new double[opts.n_seq * opts.n_seq];
    dist_fuzzy = new double[opts.n_seq * opts.n_seq];
    dist_fuzzy_t = new double[opts.n_seq * opts.n_seq];
    dist_somiglianza = new double[opts.n_seq * opts.n_seq];
    dist_somiglianza_t = new double[opts.n_seq * opts.n_seq];
    for (i = 0; i < opts.n_seq * opts.n_seq; i++) {
        dist_shan[i] = 0;
        dist_shan_r[i] = 0;
        dist_top[i]=0;
        dist_top_r[i]=0;
        dist_ham[i]=0;
        dist_fuzzy[i]=0;
        dist_fuzzy_t[i]=0;
        dist_somiglianza[i]=0;
        dist_somiglianza_t[i]=0;
    }

    if(opts.verbose)
        fprintf(stderr,"Calculating distance matrix\n");
    
    distance d(opts.seq_len);
    
#pragma omp parallel for firstprivate(d) schedule(dynamic)
    for (i = 0; i < opts.n_seq; i++){
        for (int j = i + 1; j < opts.n_seq; j++) {
            int index=i*opts.n_seq+j;
            d.fill(entries[i], entries[j]);
            
            dist_shan[index] = d.dist_s;
            dist_shan_r[index] = d.dist_s_r;
            dist_top[index]=d.dist_top;
            dist_top_r[index]=d.dist_top_r;
            dist_ham[index]=d.dist_ham;
            
            dist_fuzzy[index]=d.dist_fuzzy;
            dist_fuzzy_t[index]=d.dist_fuzzy_t;
            
            dist_somiglianza[index]=d.somiglianza;
            dist_somiglianza_t[index]=d.somiglianza_t;
        }
    }


    //
    //  WRITING THE OUTPUT
    //
    if (opts.write == true) {
	char outputname[255];
        out = fopen("output-dist.bin", "w");
        i = fwrite(dist_shan, sizeof (double), opts.n_seq * opts.n_seq, out);
	printf("Written %d (/%d = %d^2)\n",i,opts.n_seq*opts.n_seq,opts.n_seq);
        fclose(out);

        out = fopen("output-distr.bin", "w");
        i = fwrite(dist_shan_r, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);

        out = fopen("output-top.bin", "w");
        i = fwrite(dist_top, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);

        out = fopen("output-topr.bin", "w");
        i = fwrite(dist_top_r, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
        
        out = fopen("output-ham.bin", "w");
        i = fwrite(dist_ham, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
        
        out = fopen("output-simil.bin", "w");
        i = fwrite(dist_somiglianza, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
        
        out = fopen("output-simil_t.bin", "w");
        i = fwrite(dist_somiglianza_t, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
        
        
	//sprintf(outputname,"output-fuzzy-%02d.bin",opts.fuzzy);
	sprintf(outputname,"output-fuzzy.bin");
        out = fopen(outputname, "w");
        i = fwrite(dist_fuzzy, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
        
	sprintf(outputname,"output-fuzzyt.bin");
        out = fopen(outputname, "w");
        i = fwrite(dist_fuzzy_t, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
     
        if(opts.verbose)
            fprintf(stderr,"Written 7x distance matrix\n");
    }
    //
    //  PROGRAM EXIT
    //
    return 0;
}
