/* 
 * Author: Dawid Crivelli
 *
 * Started on January 11, 2012, 2:30 PM
 * 
 * 
 * Version: 3.0, 2012/01/15
 * -Generic partition building
 * -Partitioning of arbitrary symbol strings
 * -Generic intersection and (unreduced) distance
 * -Inheritance classes
 * 
 * Version: 2.0, 2012/01/13
 * -Reading from files
 * -Help system 
 * -Thorough input options
 * 
 * Version: 1.0, 2012/01/12
 * -Partitioning
 * -Distance matrix calculation
 */

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>

#include "strutture.h"

extern options opts;
double *mylog;


int main(int argc, char** argv) {
    int i, j;
    
    double *dist_shan;
    double *dist_shan_r;
    double *dist_top;
    double *dist_top_r;
    double *dist_ham;
    double *dist_fuzzy;
    double *dist_fuzzy_t;
    FILE *out;
    dist_tuple res;
    

    set_program_options(opts,argc,argv);
    
    
    //random number initialization
    srand(opts.seed);
    
    //
    //  ALLOCATION OF MEMORY AND INITIALIZATION
    //
    entry *entries = new entry[opts.n_seq];
    create_temp_arrays(opts);
    
    //logarithm lookup table, 6x program speedup
    mylog = new double[opts.seq_len + 10];
    for (int i = 1; i < opts.seq_len + 10; i++)
        mylog[i] = log(i);
    mylog[0]=0;
    

    //distance matrix allocation and zeroing
    dist_shan = new double[opts.n_seq * opts.n_seq];
    dist_shan_r = new double[opts.n_seq * opts.n_seq];
    dist_top = new double[opts.n_seq * opts.n_seq];
    dist_top_r = new double[opts.n_seq * opts.n_seq];
    dist_ham = new double[opts.n_seq * opts.n_seq];
    dist_fuzzy = new double[opts.n_seq * opts.n_seq];
    dist_fuzzy_t = new double[opts.n_seq * opts.n_seq];
    for (i = 0; i < opts.n_seq * opts.n_seq; i++) {
        dist_shan[i] = 0;
        dist_shan_r[i] = 0;
        dist_top[i]=0;
        dist_top_r[i]=0;
        dist_ham[i]=0;
        dist_fuzzy[i]=0;
        dist_fuzzy_t[i]=0;
    }

    
    //
    //  CREATION OF RANDOM SEQUENCES (as entries)
    //
    if(opts.random_sequences){
        fill_entries_randomly(opts,entries);
    }

    //
    //  READ SEQUENCES FROM FILE
    //
    if(opts.random_sequences==false){
        fill_entries_from_file(opts,entries);
    }
    
    if(opts.verbose)
        fprintf(stderr,"Entries filled\n");
    //
    //  ANALISYS OF LOADED SEQUENCES
    //
    for (i = 0; i < opts.n_seq; i++) {
        entries[i].make_partition();
        if (opts.verbose >0)
            entries[i].print();
        
    }
    //
    //  DISTANCE MEASUREMENTS
    //
    if(opts.distance==false)
        exit(0);
    
    if(opts.verbose)
        fprintf(stderr,"Calculating distance matrix\n");
    
    for (i = 0; i < opts.n_seq; i++)
        for (j = i + 1; j < opts.n_seq; j++) {
            int index=i*opts.n_seq+j;
            res = distance(entries[i], entries[j]);
            dist_shan[index] = res.dist_s;
            dist_shan_r[index] = res.dist_s_r;
            dist_top[index]=res.dist_top;
            dist_top_r[index]=res.dist_top_r;
            dist_ham[index]=res.dist_ham;
            
            res = general_distance(entries[i].X,entries[j].X);
            dist_fuzzy[index]=res.dist_fuzzy;
            dist_fuzzy_t[index]=res.dist_fuzzy_t;
        }
    


    //
    //  WRITING THE OUTPUT
    //
    if (opts.write == true) {
        out = fopen("output-dist.bin", "w");
        i = fwrite(dist_shan, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);

        out = fopen("output-distr.bin", "w");
        i = fwrite(dist_shan_r, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);

        out = fopen("output-top.bin", "w");
        i = fwrite(dist_top, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);

        out = fopen("output-topr.bin", "w");
        i = fwrite(dist_top_r, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
        
        out = fopen("output-ham.bin", "w");
        i = fwrite(dist_ham, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
        
        out = fopen("output-fuzzy.bin", "w");
        i = fwrite(dist_fuzzy, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
        
        out = fopen("output-fuzzyt.bin", "w");
        i = fwrite(dist_fuzzy_t, sizeof (double), opts.n_seq * opts.n_seq, out);
        fclose(out);
     
        if(opts.verbose)
            fprintf(stderr,"Written 7x distance matrix\n");
    }
    //
    //  PROGRAM EXIT
    //
    return 0;
}