#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <stdio.h>
#include "strutture.h"

extern options opts;
extern double *mylog;

void general_partition::print() {
    if (opts.verbose > 3) {
        fprintf(stdout, "Adv: {%d", 1);
        for (int i = 1; i < N; i++)
            fprintf(stdout, ",%d", labels[i] - labels[0] + 1);
        fprintf(stdout, "}\n");
    }
    fprintf(stdout, "Sizes: {%d", atom_sizes[0]);
    for (int i = 1; i < n; i++)
        fprintf(stdout, ",%d", atom_sizes[i]);
    fprintf(stdout, "}\n");
}

void partition::print() {
    // {1,3,4,...}
    if (opts.verbose > 2) {
        fprintf(stdout, "Simp: {%d", atom_positions[0]);
        for (int k = 1; k < n; k++)
            fprintf(stdout, ",%d", atom_positions[k]);
        fprintf(stdout, "}\n");
    }
    if (opts.verbose > 3) {
        // {1,0,0,1,0,1,...}
        fprintf(stdout, "{%d", binary[0]);
        for (int k = 1; k < N; k++)
            fprintf(stdout, ",%d", binary[k]);
        fprintf(stdout, "}\n");
    }
}

void entry::print() {
    //sequence name and code
    
    fprintf(stdout, "Seq%03d",this->index);
    if(opts.verbose>1)
        fprintf(stdout, " (%s)",this->name);
    if(this->n < 100)
        fprintf(stdout, ": %s\n", this->seq);
    else
        fprintf(stdout, ": %.20s...\n", this->seq);
    
    //print the whole partition
    if(opts.verbose>2)
        Z->print();
    //adding the entropy information
    fprintf(stdout, "Partitions: %d, Shannon %f, Topological %f\n", Z->n,Z->entropia_shannon,
            Z->entropia_topologica);
    
    if (X && X->n) {
        //print the whole partition
        if (opts.verbose > 2)
            X->print();
        //adding the entropy information
        fprintf(stdout, "Partitions: %d, Shannon %f, Topological %f\n", X->n, X->entropia_shannon,
                X->entropia_topologica);
    }
    fprintf(stdout,"\n");
    
}

template <typename T>
partition::partition(const T* seq, int len) {
    int i, j;
    
    //Total length of the partition is equal to the sequence
    N = len;
        
    binary = new int[len];
    atom_positions = new int[len];

    //first one always start an atom
    binary[0] = 1;

    //checking for a different symbol from the one before
    //when that happens => new atom!
    for (i = 1; i < len; i++)
        binary[i] = seq[i] != seq[i - 1];

    //now going back and writing the atom positions
    j=0;
    for (i = 0; i < len; i++)
        if (binary[i]) {
            atom_positions[j++] = i + 1;
        }
    //number of atoms found - index++ of last the atom in the array (zero addressing)
    n = j;
    entropia_topologica=mylog[n];
    entropia_shannon=entropy_binary_partition(binary,N);

}

template <typename T>
general_partition::general_partition(const T* seq, int len,int fuzzy) {
    int i, j;
    //this run's  atoms count
    int label_count;
    //position of the last site belonging to the atom we're trying to add to
    int last_good;
    //Total length of the partition is equal to the sequence
    N = len;
    entropia_shannon=0;
    entropia_topologica=0;
    
    if(fuzzy==-1)
        fuzzy=opts.fuzzy;
     
    //position of first symbol (0 based index)
    atom_positions = new int[N];
    
    //size of atoms (0 based index)
    atom_sizes=new int[N];
    labels=new int[N];
    //we initialize it for compatibility, when fuzzy=0
    binary=new int[N];

    //presetting labels for this partition to 0
    for (i=0;i<N;i++){
        labels[i]=0;
        binary[i]=0;
    }
    
    //beginning count of identified atoms
    label_count=0;
    //we check every site for belonging to a partition set
    for (i=0;i<N;i++){
        //if the site was already "colored" check the next one
        if (labels[i])
            continue;
        //we give a new label to the site
        binary[i]=1;
        label_count++;
        atom_positions[label_count-1]=i;
        labels[i]=label_count;
        
        //we know that it belongs (first, trivial)
        last_good=i;
        int this_atom_size=1;
        //now we add all the other possible sites to it, starting from i+1!
        //staying below N
        //and allowing a spacing of at most opts.fuzzy spaces between them
        for(j=i+1; j<last_good+fuzzy+2 && j<N; j++){
            
            //if it belongs to the same cluster...
            if(seq[j]==seq[i]){
                //..we label it accordingly
                labels[j]=label_count;
                //and marking it as "good" (since we're on an ordered line)
                last_good=j;
                this_atom_size++;
            }
        }
        atom_sizes[label_count-1]=this_atom_size;
        entropia_shannon+=this_atom_size * mylog[this_atom_size];
        
        
    }
    //this many different atoms were found
    entropia_shannon=-entropia_shannon/N+mylog[N];
    n=label_count;
    entropia_topologica=mylog[n];

}
template general_partition::general_partition(const int *, int, int);

void entry::make_partition(){
        Z=new partition(seq,n);
        X=new general_partition(seq,n);
    }


