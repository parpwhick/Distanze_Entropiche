#include <cstdlib>
#include <cstdio>
#include <string>
#include <vector>

//#include <unordered_map>

#include "strutture.h"


extern options opts;
extern double *mylog;
extern int *colore;

#define	FORCE_INLINE __attribute__((always_inline))


FORCE_INLINE void DJBHASH_STEP(u_int32_t &hash, u_int32_t value) {
    hash = (hash << 5) + hash + (0xff000000 & value);
    hash = (hash << 5) + hash + (0x00ff0000 & value);
    hash = (hash << 5) + hash + (0x0000ff00 & value);
    hash = (hash << 5) + hash + (0x000000ff & value);
}



void print_array(int *array, int len, const char *nome) {
    printf("%s {%3d", nome, array[0]);
    for (int i = 1; i < len; i++)
        printf(",%3d", array[i]);
    printf("}\n");
}


/************************************************
 ************************************************
 *             PARTIZIONI SEMPLICI              *
 ************************************************
 ************************************************
 */


void partition::print() {
   if (opts.verbose > 3) {
        // {1,0,0,1,0,1,...}
       print_array(binary,N,"Binary");
    }
    fprintf(stdout, "Partitions[n]: %d, Shannon %f, Topological %f\n", n,entropia_shannon,
            entropia_topologica);
}

template <typename T>
partition::partition(const T* seq, int len) {
    this->fill(seq,len);
}

template <typename T>
void partition::fill(const T* seq, int len) {
    int i, j;
    
    //Total length of the partition is equal to the sequence
    N = len;
        
    binary = new int[len];
    //atom_positions = new int[len];

    //first one always start an atom
    binary[0] = 1;

    //checking for a different symbol from the one before
    //when that happens => new atom!
    for (i = 1; i < len; i++)
        binary[i] = seq[i] != seq[i - 1];

    //now going back and writing the atom positions
    j=0;
    for (i = 0; i < len; i++)
        if (binary[i]) {
            //atom_positions[j++] = i + 1;
            j++;
        }
    //number of atoms found - index++ of last the atom in the array (zero addressing)
    n = j;
    entropia_topologica=mylog[n];
    entropia_shannon=entropy_binary_partition(binary,N);
}
template void partition::fill(const char *, int);



template <typename T>
linear_partition::linear_partition(const T* seq, int len,int fuzzy) {
    labels=0;
    N=0;
    prev_site=0;
    this->from_linear_sequence(seq,len,fuzzy);
}




/************************************************
 ************************************************
 *            PARTIZIONI COMPLESSE              *
 ************************************************
 ************************************************
 */





void linear_partition::allocate(int len){
    N=len;
    labels=new int[N];
    prev_site=new int[N];
    
    atomi=new atom[N];
}

linear_partition::linear_partition(int len) {
    n=0;
    N=len;
    entropia_topologica=0;
    entropia_shannon=0;
    
    
    if(N)
        allocate(N);
    else{
        labels=0;
        prev_site=0;
       atomi=0;        
    }    
}

linear_partition::~linear_partition(){
    if (N) {
        delete []labels;
        delete []prev_site;
        delete []atomi;
    }
    
}

template <typename T>
void linear_partition::from_linear_sequence(const T* seq, int len) {
    int i, j;
    int last_good;
    
    N=len;
    if(!labels)
        allocate(N);
    
    dim=1;
    //presetting labels for this partition to 0
    for (i=0;i<N;i++)
        prev_site[i]=0;
     
    for (i=0;i<N;i++){
        //if the site was already "colored" check the next one
        if (prev_site[i])
            continue;     
        last_good=i;
        prev_site[i]=i;
        
        for(j=i+1; j<last_good+opts.fuzzy+2 && j<N; j++)
            //if it belongs to the same cluster...
            if(seq[j]==seq[i]){
                prev_site[j]=last_good;
                last_good=j;
            }
    }
    NNB=new int*[dim];
    NNB[0]=prev_site;
    
    from_nnb(NNB,dim);    
}
template void linear_partition::from_linear_sequence(const char *, int);
template void linear_partition::from_linear_sequence(const int *, int);

template <typename T>
void print_square_lattice(const T* valori, int lato, int dimensioni){
//    if(dimensioni != 4){
//        printf("Printing only 2d now, exiting\n");
//        exit(1);
//    }
    for(int i=0; i < lato; i++){
        for(int j=0; j < lato; j++){
            printf("%2d ",valori[j*lato+i]);
        }
        printf("\n");
    }
    printf("\n");
}

template <typename T>
void ppmout(const T *grid1, int sz, const char *filename) {

    if(colore==0){
        colore = new int[opts.seq_len];
        for (int i = 0; i < opts.seq_len; i++) {
            colore[i] = xrand();
        }
        colore[0] = 0x0F5A3A1F; // blue almost black
    }
    
    int MULT;
    if(sz > 500)
        MULT=1;
    else
        MULT=500/sz + 1;
    
    
    FILE *fout = fopen(filename,"w");
    fprintf(fout, "P6\n %d %d\n 255\n", MULT*sz, MULT*sz);


    for (int rg = 0; rg < sz; rg++) {
        for (int i = 0; i < MULT; i++)
            for (int cl = 0; cl < sz; cl++) {
                int sito=grid1[rg * sz + cl] % opts.seq_len;
                int color = colore[sito];
                for (int j = 0; j < MULT; j++)
                    fwrite(&color, 3, 1, fout);
            }
    }
}
template void ppmout(const int *grid, int sz, const char *filename);
template void ppmout(const unsigned long*grid, int sz, const char *filename);

template <typename T, typename U>
void ppmout2(const T *grid1, const U* grid2, int sz, const char *filename) {
    if(colore==0){
        colore = new int[opts.seq_len];
        for (int i = 0; i < opts.seq_len; i++) {
            colore[i] = xrand();
        }
        colore[0] = 0x0F5A3A1F; // blue almost black
    }
    
    int MULT;
    if(sz > 500)
        MULT=3;
    else
        MULT=500/sz + 1;
    
    
    int black=0x20202020;
    int intermezzo=100; //pixels tra i pannelli
    
    FILE *fout = fopen(filename,"w");
    fprintf(fout, "P6\n %d %d\n 255\n", 2*MULT*sz+intermezzo, MULT*sz);

    for (int rg = 0; rg < sz; rg++) {
        for (int i = 0; i < MULT; i++){
            //primo reticolo
            for (int cl = 0; cl < sz; cl++) {
                int sito=grid1[rg * sz + cl] % opts.seq_len;
                int color = colore[sito];
                for (int j = 0; j < MULT; j++)
                    fwrite(&color, 3, 1, fout);
            }
            //10 pixels neri in mezzo
            for (int j = 0; j < intermezzo; j++)
                    fwrite(&black, 3, 1, fout);
            
            //secondo reticolo
            for (int cl = 0; cl < sz; cl++) {
                int sito=grid2[rg * sz + cl] % opts.seq_len;
                int color = colore[sito];
                for (int j = 0; j < MULT; j++)
                    fwrite(&color, 3, 1, fout);
            }
        }
    }
}
template void ppmout2(const int *grid1, const int* grid2, int , const char *) ;
template void ppmout2(const unsigned long *grid1, const unsigned long* grid2, int , const char *) ;




#define nnu (i - (i % lato)+ ((i+lato-1)%lato))
#define nnd ((i/lato)*lato + ((i+lato+1)%lato))
#define nnl (i+N-lato)%N
#define nnr (i+N+lato)%N
template <typename T>
void linear_partition::from_square_lattice(const T* valori, int L,int dimensioni) {
    int i=0,j=0;
    
    static int imagenr=0; 
    imagenr++;
    char filename[255];
    
    N=1;
    dim=dimensioni;
    for(j=0;j<dim;j++)
        N *= L;
    lato=L;

    
    
    if(!labels)
        allocate(N);
    
    NNB=new int*[dim];
    for(j=0;j<dim;j++)
        NNB[j]=new int[N];

    if (dim == 1) {
        NNB[0][0]=0;
        for (i = 1; i < N; i++) 
            NNB[0][i] = (valori[i]==valori[i-1]) ? i-1 : -1;
    }
    if (dim == 2) {
        for (i = 0; i < N; i++) {
            NNB[0][i] = (valori[i] == valori[nnu]) ? nnu : i;
            NNB[1][i] = (valori[i] == valori[nnl]) ? nnl : i;
            //NNB[2][i] = (valori[i] == valori[nnd]) ? nnd : i;
            //NNB[3][i] = (valori[i] == valori[nnr]) ? nnr : i;
        }
    } else {
        /* MULTIDIMENSIONALE GENERICO */
        int salto = 1;
        int vicino;
        for (j = 0; j < dim; j++) {
            for (i = 0; i < N; i++) {
                vicino = (i - salto + N) % N;
                NNB[j][i] = (valori[i] == valori[vicino]) ? vicino : -1;
            }
            salto *= L;
        }
    }  
    
    //Calcola la partizione, a partire dalla mappa dei vicini
     from_nnb(NNB,dim); 
     
//    printf("%% valori\n");
//    print_square_lattice(valori,lato,dimensioni);
//    sprintf(filename,"lattice%02d.ppm",imagenr);
//    ppmout(valori,lato,filename);
//    printf("%% nnu\n");
//    print_square_lattice(NNB[0],lato,dimensioni);
//    printf("%% nnl\n");
//    print_square_lattice(NNB[1],lato,dimensioni);
//    printf("%% partizione\n");
//    print_square_lattice(labels,lato,2);
//    sprintf(filename,"partizione%02d.ppm",imagenr);
//    ppmout(labels,lato,filename);
        
      sprintf(filename,"realizzazione%03d.ppm",imagenr);
      if(opts.graphics)
          ppmout2(valori,labels,L,filename);
      
}
template void linear_partition::from_square_lattice(const int* , int ,int );




inline int compare (const void * a, const void * b){
  return ( *(int*)a - *(int*)b );
}

void linear_partition::sort_entropy(){
    int i;
    int label_count = 0;
    double H = 0;
    int mu;
    int begin;
    
    
    int *temp=new int[N];
    
    for(int i=0; i<N;i++)
        temp[i]=labels[i];
    
    qsort(temp,N,sizeof(temp[0]),compare);
    
    //the first position always starts an atom
    begin = 0;
    label_count=1;
    int old_val=temp[0];
        
    for (i = 1; i < N; i++) {      
        //whenever we find a new atom
        if (temp[i]!=old_val) {
            //a new atom starts
            
            //the closed (old)atom's length is calculated
            mu = i - begin;           
            //the new one is ready to go
            label_count++;
            begin = i;
            //cache the new label to check
            old_val=temp[i];
            //we add the entropy, with the trick mu>0 and when mu=1 the log is 0
            if (mu > 1)
                H += (double) mu * mylog[mu];   
        }
    }
    //the last one, so it's not left hanging
    mu = N - begin;
    H += mu * mylog[mu];
    
    //normalize the result
    H = -H / N + mylog[N];
    
    entropia_topologica=mylog[label_count];
    n=label_count;
    entropia_shannon=H;
    
    delete []temp;
}

void linear_partition::reduce(const linear_partition &ridurre, const linear_partition &common){
      
    if(!labels)
        allocate(N);
  
    for(int i=0;i<N;i++){
        labels[i]=1;
    }
    int fattori_indipendenti=0;
    lato=ridurre.lato;
    
    //per ogni atomo
    for(int which=0;which<ridurre.n;which++){
       const atom &atomo_ridurre=ridurre.atomi[which];
       const atom &atomo_common =common.atomi[common.labels[atomo_ridurre.end]];
       
       if(atomo_ridurre == atomo_common)
           continue;
  
        //altrimenti interseca il fattore dicotomico con i precedenti
        fattori_indipendenti++;
        for (int i = ridurre.atomi[which].end;; i = ridurre.prev_site[i]) {
            labels[i] *=fattori_indipendenti+1;
            if (i == ridurre.prev_site[i])
                break;
        }
        
    }   
    //tutti i labels verranno mischiati - TEMP ARRAY NECESSARIO IN sort_entropy
    this->sort_entropy();
}

int findroot(int i,int *ptr)
{
  if (ptr[i]<0) return i;
  return ptr[i] = findroot(ptr[i],ptr);
}

void linear_partition::linear_intersection(const linear_partition &p1, const linear_partition &p2){
    static int imagecount=0; 
    
    char filename[255];
    
    
    int *vicinato[2 * p1.dim];
    lato=p1.lato;
    
    for(int i=0; i < p1.dim;i++){
        vicinato[2*i]=p1.NNB[i];
        vicinato[2*i+1]=p2.NNB[i];
    }
    from_nnb(vicinato,2 * p1.dim);
    
    
    
      if(opts.graphics){
          imagecount++;
          sprintf(filename,"comune%03d.ppm",imagecount);
          ppmout2(p1.labels,p2.labels,lato,filename);
          imagecount++;
          sprintf(filename,"comune%03d.ppm",imagecount);
          ppmout(labels,lato,filename);
      }
    
}


void linear_partition::from_nnb(int **neighbors, int dimensione){
    int s1, s2;
    int i;


    dim=dimensione;
    
    
    
    //presetting labels for this partition to 0
    for (i = 0; i < N; i++) {
        labels[i] = -1;
    }    
    
    /* FASE DI PERCOLAZIONE
     * E LABELLING
     */
    
    for (s1 = 0; s1 < N; s1++) {
        int r2;
        int r1=findroot(s1,labels);
        
        //printf("%d ha come vicini: %d e %d\n",s1,neighbors[0][s1],neighbors[1][s1]);
        for (int j = 0; j < dim; j++) {
            s2=neighbors[j][s1];
                if(s1==s2 || s2 < 0)
                    continue;
		r2=findroot(s2,labels);
 //               print_array(labels,20,"labels");
//               printf("%% partizione-in progress\n");
//                print_square_lattice(labels,3,2);
                
//                printf("%d--->%d(%d)\n",s1,s2,r2);
		if(r1!=r2){
			if(labels[r1]>=labels[r2]){ //VERSIONE GIUSTA!
 //                          printf("%d=>%d\n",r1,r2);
				labels[r2]+=labels[r1];
				labels[r1]=r2;
				r1=r2;
			}
			else{
//                          printf("%d=>%d\n",r2,r1);
				labels[r1]+=labels[r2];
				labels[r2]=r1;
			}
		}
	}
    }
    
    /* SCRITTURA ARRAY DEGLI ATOMI
     * E next_site e prev_site 
     */
    
   int *new_site_label=new int[N];
    
    entropia_shannon=0;
    int label_count=0;
    
    for(i=0;i<N;i++){
        if(labels[i]<0){
            entropia_shannon+= -labels[i]*mylog[-labels[i]];
            //atomi[label_count].size=-labels[i];
            atomi[label_count].hash=5381;
            atomi[label_count].end=i;
            new_site_label[i]=label_count;
            prev_site[i]=i;
            label_count++;
        }      
        else{
            prev_site[i]=findroot(i,labels);
            new_site_label[i]=prev_site[i];
            //next_site[i]=i;
        }
      //  print_array(new_site_label,L,"newlabels");
    }
    
    #undef HASHVAR
    #define HASHVAR atomi[atom_pos].hash
    for(i=0;i<N;i++){
        int atom_pos=new_site_label[prev_site[i]];
        labels[i]=atom_pos;
        DJBHASH_STEP(HASHVAR,i);
        prev_site[i]=std::min(atomi[atom_pos].end,i);
        //next_site[prev_site[i]]=i;
        atomi[atom_pos].end=i;
      
    }
    
    delete []new_site_label;
    
    n=label_count;
    entropia_topologica=mylog[n];
    entropia_shannon= -entropia_shannon/N+mylog[N];
}

